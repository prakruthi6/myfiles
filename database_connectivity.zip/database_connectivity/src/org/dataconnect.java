package org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Statement;


@WebServlet("/dataconnect")
public class dataconnect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	@Resource(name="jdbc/project")
	private DataSource dataSource;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//step1 initialize connection objects 
		PrintWriter out=response.getWriter();
		Connection connect=null;
		Statement stmt=null;
		ResultSet rs=null;
		try {
			connect=dataSource.getConnection();
			
			//step 2: Create a sql statement string
			String query="Select * from person1";
			stmt= connect.createStatement();
			
			//step3 :Execute sql query
			rs=stmt.executeQuery(query);
			
			//step4: process the result set
			while(rs.next() ) {
				out.print("<br/>"+rs.getString("email"));
			}
			} catch(SQLException e) {
				e.printStackTrace();
			}
	}
	
    public dataconnect() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
