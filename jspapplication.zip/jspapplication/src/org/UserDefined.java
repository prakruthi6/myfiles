package org;

public class UserDefined {
public String Demo() {
	return "Demo method";
}
}
