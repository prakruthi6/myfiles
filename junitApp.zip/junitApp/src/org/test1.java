package org;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

class test1 {

	@BeforeClass
	public static void setUpbeforeClass() throws Exception {
		System.out.println("before class");
	}
	@Before
	public static void setUpbefore() throws Exception {
		System.out.println("before");
	}
	@Test
	void testFindMax() {
		System.out.println("test case find max");
		assertEquals(5,calculation.findMax(new int[] {5,4,3,1}));
	}
	@Test
	void testFindMin() {
		System.out.println("test case find min");
		assertEquals(1,calculation.findMin(new int[] {5,4,3,1}));
	}
	@Test
	void testcube() {
		System.out.println("test case cube");
		assertEquals(27,calculation.cube(3));
	}
	@After
	public static void tearDown() throws Exception {
		System.out.println("after");
	}
	@AfterClass
	public static void tearDownClass() throws Exception {
		System.out.println("after class");
	}
}
