package org.slk.showroom;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Root resource (exposed at "Brands" path)
 */
@Path("/showroom")
public class Brands {

    @GET
    @Path("/getBrands")
    @Produces(MediaType.TEXT_PLAIN)
    public  String getBrands() {
    	try {
    		String url = "jdbc:mysql://localhost:3306/prakruthi?useSSL=false";
    		String uname = "root";
    		String pass = "1234";
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection(url, uname, pass);
    		String query = "select * from person1";
    		Statement st = con.createStatement();
    		ResultSet rs = st.executeQuery(query);
    		while (rs.next()) {
    		int id = rs.getInt("id");
    		String name = rs.getString("name");
    		String email = rs.getString("email");
    		
    		Long phone = rs.getLong("phone");
    
    		System.out.println(id + " " + name + " " + email + " " + " "+ phone);
    		
    		}
    		} catch (Exception e) {
    		System.out.println("Cannot connect to the Database");
    		}

    	return "Listed";
    	
       
    }
    @POST
    @Path("/setBrands")
    @Produces(MediaType.TEXT_PLAIN)
    public String setBrands()
    {
    	return "Add a new brand";
    }
    
    @PUT
    @Path("/Brands/{brandId}")
    @Produces(MediaType.TEXT_PLAIN)
    public String putBrands(@PathParam("brandId") int brandId)
    {
    	return "Update brand info with ID "+brandId;
    }
    
    @DELETE
    @Path("/Brands/{id}")
    @Produces(MediaType.TEXT_PLAIN)
    public String deleteBrands(@PathParam("id") int id)
    {
    	try {
    		String url = "jdbc:mysql://localhost:3306/prakruthi?useSSL=false";
    		String uname = "root";
    		String pass = "1234";
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection(url, uname, pass);
    		String query = "alter table person1 drop column email where id= "+id;
    		Statement st = con.createStatement();
    		ResultSet rs = st.executeQuery(query);
    		while (rs.next()) {
    	     id = rs.getInt("id");
    		String name = rs.getString("name");
    		String email = rs.getString("email");
    		
    		Long phone = rs.getLong("phone");
    
    		System.out.println(id + " " + name + " " + email + " " + " "+ phone);
    		
    		}
    		} catch (Exception e) {
    		System.out.println("Cannot connect to the Database");
    		}
    	return "Deleted brand info with ID "+id;
    }
}
