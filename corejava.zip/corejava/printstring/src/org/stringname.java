package org;

public class stringname {
 public String fname;
 public String lname;
 
 public void display()
 {
	 System.out.println(fname+" "+lname);
 }
}
