package org;

public class stringtest {

	public static void main(String[] args) {
		stringname obj1=new stringname();
		obj1.fname="Prakruthi";
		obj1.lname="Chandrashekar";
		obj1.display();
	}

}
