package Collectioneg;
import java.util.*;

public class collectionexample {
public void hashsetexample()
{
	//Hashset declaration
	HashSet<String> hset=new HashSet<String>();
	//Adding elements to Hashset
	hset.add("Apple");
	hset.add("Mango");
	hset.add("Grapes");
	hset.add("Pine");
	hset.add("FIg");
	//Duplication
	hset.add("Apple");
	hset.add("Mango");
	//Adding null values
	hset.add("Null");
	hset.add("Null");
	//Displaying hashset elements
	System.out.println(hset);
}

public void treesetExample()
{
	TreeSet<String> al=new TreeSet<String>();
	{
		al.add("Ravi");
		al.add("Ajay");
		al.add("Ravi");
		al.add("Vijay");
		//Traversing elements
		Iterator<String> itr=al.iterator();
		while(itr.hasNext()) 
		{
			System.out.println(itr.next());
		}
	}
}
	 
public void listExample()
{
	List<String> al=new ArrayList<String>();
	al.add("Amit");
	al.add("Vijay");
	al.add("Kumar");
	al.add(1,"Sachin");
	System.out.println("An element at 1st pos: "+al.get(2));
	for(String s:al)
	{
		System.out.println(s);
	}
}
public void queueExample()
{
	Queue<String> queue=new PriorityQueue<String>();
	
queue.add("Amit");
queue.add("Vijay");
queue.add("Karan");
queue.add("Upasana");
queue.add("Rahul");
System.out.println("head:"+queue.element());
System.out.println("head:"+queue.peek());
System.out.println("iterarting the queue elements");
Iterator<String> itr=queue.iterator();
while(itr.hasNext())
{
System.out.println(itr.next());
}
queue.remove();
queue.poll();
System.out.println("after receiving two elements");
Iterator<String> itr2=queue.iterator();
while(itr2.hasNext())
{
	System.out.println(itr2.next());
}
}
   public void linkedlistExample()
   {
	   LinkedHashSet<String> al=new LinkedHashSet<String>();
	   al.add("Ravi");
	   al.add("vijay");
	   al.add("Ravi");
	   al.add("Ajay");
	   Iterator<String> itr=al.iterator();
	   while(itr.hasNext()) {
		   System.out.println(itr.next());
	   }
   }
   
   public void vectorExample()
   {
	   Vector<String> v=new Vector<String>();
	   v.add("Ayush");
	   v.add("Amit");
	   v.add("Ashsih");
	   v.add("Garima");
	   Iterator<String> itr=v.iterator();
	   while(itr.hasNext()) {
		   System.out.println(itr.next());
	   }
   }
   
   public void StackExample()
   {
	   Stack<String> s=new Stack<String>();
	   s.add("Ayush");
	   s.add("Garvit");
	   s.add("Amit");
	   s.add("Ashish");
	   s.add("Garima");
	   s.pop();
	   Iterator<String> itr=s.iterator();
	   while(itr.hasNext()) {
		   System.out.println(itr.next());
	   }
   }
   
   public void MapExample()
   {
	   Map<Integer,String> map=new HashMap<Integer,String>();
	   map.put(100,"Amit");
	   map.put(101,"Vijay");
	   map.put(102,"Rahul");
	   //Elements can traverse in any order
	   //for(String s:names)
	   for(Map.Entry m:map.entrySet())
	   {
		   System.out.println(m.getKey()+" "+m.getValue());
	   }
   }
   
   public static void main(String[] args)
   {
	   collectionexample obj=new collectionexample();
	   obj.hashsetexample();
	   obj.treesetExample();
	   obj.listExample();
	   obj.queueExample();
	   obj.linkedlistExample();
	   obj.vectorExample();
	   obj.StackExample();
	   obj.MapExample();
			   
	 
   }

	
}

   
   
   
   
   
   
   
