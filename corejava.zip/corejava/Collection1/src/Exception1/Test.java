package Exception1;

public class Test {

	public static void main(String[] args) {
		Myclass c=new Myclass();
		c.method1();
       
		try {
			c.method2();
		} catch (Exception e) {
			 System.out.println("divide by zero");
			 
		}
	}

}
