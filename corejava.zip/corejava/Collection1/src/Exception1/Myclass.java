package Exception1;

public class Myclass {
//two ways to deal with exception
	//handle it
	public void method1() {
		try {
			int z=10/0;
			int[] x=new int[5];
			x[6]=20;
		} catch(ArithmeticException e) {
			System.out.println("A Number divided by zero leads to infinity");
		}catch(IndexOutOfBoundsException e) {
			System.out.println("Referring array element out boundry");
		}finally 
		{
			System.out.println("This block has to be executed irrespective of an exception");
			
		}
	}//Declare it
	public void method2() throws Exception {
		int x=10;
		int y=0;
		int z=10/0;
	}	
}
