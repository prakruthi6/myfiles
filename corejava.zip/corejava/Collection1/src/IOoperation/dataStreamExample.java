package IOoperation;

import java.io.FileInputStream;

public class dataStreamExample {

	public static void main(String[] args) {
		try {
			FileInputStream fin=new FileInputStream("C:\\prakruthi\\corejava\\pc.txt");
//			int i=fin.read();
//			System.out.println((char)i);
      		int i1=0;
			while((i1=fin.read())!=-1) {
				System.out.println(String(i1));
				
			}
			fin.close();
		}catch(Exception e) {System.out.println(e); }

	}

	private static char[] String(int i1) {
		return null;
	}

}
