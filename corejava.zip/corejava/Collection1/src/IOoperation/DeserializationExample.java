package IOoperation;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeserializationExample {

	public static void main(String[] args) {
		try {
			//Creating stream to read the object
			//FileInputStream fin=new FileInputStream("C:\\prakruthi\\corejava\\student.txt");
			//ObjectInputStream in=new ObjectInputstream(fin);
			ObjectInputStream in=new ObjectInputStream(new FileInputStream("C:"
					+ "student.txt"));
			student s=(student)in.readObject();
			//printing the data of the serialized object
			System.out.println(s.id+" "+s.name);
			//closing the stream
			in.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
