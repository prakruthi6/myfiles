package IOoperation;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SaveStudent {

	public static void main(String[] args) {
		try {
			//creating an object
			student s1=new student(211, "Prak");
			//creating stream and writing the object
			FileOutputStream fout=new FileOutputStream("C:student.txt");
			ObjectOutputStream out=new ObjectOutputStream(fout);
			out.writeObject(s1);
			out.flush();
			//closing the file
			out.close();
			System.out.println("Success");
		} catch(Exception e) {
			System.out.println(e);
		}
	}

}
