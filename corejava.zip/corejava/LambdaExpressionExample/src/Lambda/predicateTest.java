package Lambda;

import java.util.function.Predicate;

public class predicateTest {

	public static void main(String[] args) {
		Predicate<Integer> pr=a->(a>18);//Creating predicate
		System.out.println(pr.test(10));// calling predicate method
	}

}
