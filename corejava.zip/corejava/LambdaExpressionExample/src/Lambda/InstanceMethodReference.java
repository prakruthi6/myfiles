package Lambda;

public class InstanceMethodReference{
public void saysomething() {
	System.out.println("Hello,this is non-static method.");
}
	public static void main(String[] args) {
		
		InstanceMethodReference methodreference= new InstanceMethodReference(); //Creating object
		
        //referring non-static method using reference
		sayable s=methodreference::saysomething;
		//calling interface method
		s.say();
		
		//Referring non-static method using anonymous object
		sayable s2=new InstanceMethodReference()::saysomething;// you can use anonymous object also
		//calling interface method 
		s2.say();
	}

}
