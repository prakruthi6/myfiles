package Lambda;

public interface sayable {
    public String say();
	public String say(String name);
	//public void say();
}
