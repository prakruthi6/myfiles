package Lambda;
import java.util.function.Consumer;
public class ConsumerInterfaceExample {
	static void printmessage(String name) {
		System.out.println("Hello "+name);
	}
    static void printvalue(int val) {
    	System.out.println(val);
    }
	public static void main(String[] args) {
		
		//referring method to string type Consumer interface
		Consumer<String> consumer1=ConsumerInterfaceExample::printmessage;
		consumer1.accept("John"); //calling Consumer method
		
		//referring method to Integer type Consumer interface
		Consumer<Integer> consumer2=ConsumerInterfaceExample::printvalue;
	    consumer2.accept(10);
	}

}
