package Lambda;

public class multistatement {

	public static void main(String[] args) {
		
		//Multiple statements in lambda
		sayable person=(message) -> {
			String str1="I would like to say, ";
			String str2=str1+message;
			return str2;	
		};
		System.out.println(person.sayable("Time is precious"));

	}

}
