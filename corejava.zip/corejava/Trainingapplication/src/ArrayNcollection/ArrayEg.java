package ArrayNcollection;
import java.util.Scanner;

public class ArrayEg {

	public static void main(String[] args) 
	{
		int[] num1;
		num1=new int[5]; num1[0]=20; num1[1]=20; num1[2]=30; num1[3]=40; num1[4]=50;
		
		for(int i:num1) 
		{
			System.out.println(i);
		}

String[] names= {"Prak", "kruthi", "Pc", "prakss"};
        for(String i:names) //for(i=o;i<num1.length;i++)
        {
	System.out.println(i);
        }
        int[][] matrix;
        matrix=new int[3][3]; 
        Scanner sc=new Scanner(System.in);      
        System.out.println("Enter the values");
        for(int i=0;i<3;i++) {
        	for(int j=0;j<3;j++)
        	{
        		matrix[i][j]=sc.nextInt();
        	}
        }
        System.out.println("The values of matrix");
        for(int i=0;i<3;i++) {
        	for(int j=0;j<3;j++)
        	{
        		System.out.print(matrix[i][j]+" ");
        	}
        	 System.out.println();
        }
       
	}
	
}
