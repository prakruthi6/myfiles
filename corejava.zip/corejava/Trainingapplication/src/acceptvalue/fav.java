package acceptvalue;

public class fav {

}
