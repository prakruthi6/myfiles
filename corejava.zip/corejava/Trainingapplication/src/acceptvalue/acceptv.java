package acceptvalue;

import java.util.Scanner;

public class acceptv {

	public static void main(String[] args) {
		Scanner sn=new Scanner(System.in);
		System.out.println("Enter name");
		String name=sn.next();
		System.out.println("Enter age");
		int age=sn.nextInt();
		
		

String[] fav= {"kgf", "mom", "stree"};
        for(String i:fav) //for(i=o;i<num1.length;i++)
        {
	System.out.println(i);
        }
	}
}



