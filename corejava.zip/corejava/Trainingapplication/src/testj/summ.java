package testj;

public class summ {
 public int a;
 public int b;


 /*public void sum()
 {
	 int z=a+b;
	 System.out.println("The sum is "+z);
 }
 public int sum1()
 {
	int z=a-b;
	 return z;
 }
 public int sum2(int x, int y)
 {
	 int z=x+y;
	 return z;
 }
 public float sum3(int p, float q)
 {
	 float z=p+q;
	 return z;
	 }
*/
//Method overloading
public int sum()
{ return(a+b);
}
public int sum(int a, int b ) {return(a+b); }

public float sum(int a, float b) {return(a+b); }

public float sum(float a, int b) {return(a+b);}

public int sum(int x, int y, int z) {return(x+y+z);}

public String sum(String f, String l) {
	return(f+l);
}

public int sum(int...x) {
int y=0;
for(int i:x)
{
y=y+i;
}
return y;
}
public String sum(String...name)
{
	String temp="";
	for(String i:name)
	{
		temp=temp+i;
	}
	return temp;
}
}

