package testj;

public class methodm {

	public static void main(String[] args)
	{
		 summ obj=new summ();
		 obj.a=10;
		 obj.b=20;
		 
		/* obj.sum();
	     System.out.println(obj.sum1());

		 int result=obj.sum1();
		 System.out.println("The sum is "+result);
		 
		 int result1=obj.sum2(100,50);
		 System.out.println("The sum is "+result1);
		 
		 float result2=obj.sum3(100,20.1f);
	     System.out.println("The sum is "+result2);
	     */
	
		 obj.sum();
		 System.out.println(obj.sum(10,20));
		 System.out.println(obj.sum(10.5f,20));
		 System.out.println(obj.sum(10,30.5f));
		 System.out.println(obj.sum(10,20,30));
		 System.out.println(obj.sum("Prakruthi", "Chandrashekar"));
		 
		 int result=obj.sum(10,20,30,40);
		 System.out.println(obj.sum(result));
		 
		 String allnames=obj.sum("prakruthi ","Nagashree ","Praks");
		 System.out.println(obj.sum(allnames));
		 
	}

}
