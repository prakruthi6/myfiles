package org;

public class student {
 public String name;
 public int age;
 public String standard;

 public void display()
 {
	 System.out.println(name);
 System.out.println(age);
 System.out.println(standard);
 }
}
