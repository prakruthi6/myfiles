package org;

public class Test {

	public static void main(String[] args) {
		student obj1=new student();
		obj1.name="Prakruthi";
		obj1.age=15;
		obj1.standard="Ninthstd";
		obj1.display();
		
		Teacher obj2=new Teacher();
		obj2.name="hemalatha";
		obj2.course="Hindi";
		obj2.display();
	}

}
