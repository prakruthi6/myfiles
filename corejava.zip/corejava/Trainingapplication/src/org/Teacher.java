package org;

public class Teacher {
 public String name;
 public String course;

 public void display()
 {
	 System.out.println(name);
	 System.out.println(course);
 }
}
