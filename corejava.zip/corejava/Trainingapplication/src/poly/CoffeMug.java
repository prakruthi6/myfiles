package poly;

public class CoffeMug implements washable
{//Extends Mug
	public void addLiquid(Liquid l)
	{
		l.swirl();

	if (l instanceof Coffee) 
	{
		l.swirl();
	System.out.println("You got coffee");
	}
	
	else if (l instanceof Tea) 
	{
		l.swirl();
		System.out.println("You got coffee");
	
	}
	else
	{
	System.out.println("You have got some generic liquid");
	}
	}
//	Interface
	public void wash()
	{
	System.out.println("Wash the coffeemug");
	}
	public void paint()
	{
	System.out.println("Paint the coffeemug");
	}
}	
	

