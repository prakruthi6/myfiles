package poly;

public class Tea extends Liquid{
 public void swirl()
{
	System.out.println("Swirling Tea");
}
}
