package poly;

public class Test {

	public static void main(String[] args) {
		Liquid l=new Liquid();
		Coffee c=new Coffee();
		Tea t=new Tea();
		CoffeMug cm=new CoffeMug();
		cm.addLiquid(c);
		
//		Interfacing
		cm.paint();
	    cm.wash();
	}
	

}
