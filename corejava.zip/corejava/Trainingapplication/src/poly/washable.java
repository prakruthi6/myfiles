package poly;

public interface washable {
public void wash();
}
