package static1;

public class test {
public static void main(String[] args) {
	Product p1=new Product();
	System.out.println(p1.num);
	Product p2=new Product();
	System.out.println(p2.num);
	Product p3=new Product();
	System.out.println(p3.num);
	System.out.println(Product.counter);
	Product p4=new Product();
	System.out.println(p4.num);
	System.out.println(Product.counter);
	System.out.println(Product.statmethod());
	System.out.println(Product.counter);
	Product p5=new Product();
	System.out.println(p5.num);
	System.out.println(Product.counter);
	Product p6=new Product();
	System.out.println(p6.num);
	System.out.println(Product.counter);
	System.out.println(Product.statmethod());
}
}
