package static1;

public class Product {
public String name;
public int num=0;
public static int counter=0;
public static final String brandname="dabur";

public Product()
{
	counter++;
	num++;
}

public static int statmethod()
{
	counter=counter+2;
	return counter;
}
}
