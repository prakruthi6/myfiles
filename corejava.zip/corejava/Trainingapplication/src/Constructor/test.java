package Constructor;

public class test {

	public static void main(String[] args) {
		Person p1 = new Person();

		System.out.println(p1.name + " " + p1.age + " " + p1.address);

		Person p2 = new Person("Praks", 22, "Tumkuru");
		System.out.println(p2.name + " " + p2.age + " " + p2.address);
		Person p3 = new Person("Prakru", 23);
		p3.address = "Blore";
		System.out.println(p3.name + " " + p3.age + " " + p3.address);

	}

}
