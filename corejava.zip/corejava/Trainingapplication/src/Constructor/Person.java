package Constructor;

public class Person {
public String name;
public int age;
public String address;

//Constructor
public Person()
{
	name="Prakruthi";
	age=22;
	address="Tumkur";
}
public Person(String name, int age, String address)
{
this.name=name;
this.age=age;
this.address=address;
}

public Person(String n, int a)
{
	name=n;
	age=a;
}
}
