package evenodd;

public class evenoddnum {

	public static void main(String[] args) {
/*	int a=5000;
//		To find even number
		if(a!=0)
		{
		if(a%2==0)
		{
			System.out.println("Number is even"); 
		}
//		To find odd number
		else
		{
			System.out.println("Number is odd");
		} 
		}
		*/
		
		 int a=100;
		int b=222;
		String opr="%";
		switch(opr)
		{
		case "+":
			System.out.println(a+b);
			break;
		case "-":
			System.out.println(a-b);
			break;
		case "*":
			System.out.println(a*b);
			break;
		case "/":
			System.out.println(a/b);
			break;
		default:
			System.out.println("Invalid");
			
		}
		

	
}

}
