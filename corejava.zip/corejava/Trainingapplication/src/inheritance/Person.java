package inheritance;

public abstract class Person { // extends object
	public String name;
	public int age;
	
	/*public Person(String name, int age) //Inheritance
	{
		this.name=name;
		this.age=age;
	}*/


//abstract class
	/*public Person() {
		System.out.println("Person constructor");
	}*/
public abstract void something(); //{ }
}