package inheritance;

public class Manager extends Employee{
public String deptid;

/*public Manager(String name,int age,int empid,String deptid)
{
	super(name,age,empid);
	this.deptid=deptid;
}*/
}
