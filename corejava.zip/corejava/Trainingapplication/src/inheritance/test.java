package inheritance;

public class test {

	public static void main(String[] args) {
		//Abstract class
		/*Employee e=new Employee();
		e.something();
		//Inheritance
		//Manager m=new Manager("Prakruthi", 22, 109532, "Java");
		//System.out.println(m.name+" "+m.age+" "+m.empid+" "+m.deptid);
student s=new student();
s.something();
*/
		
	}

}
