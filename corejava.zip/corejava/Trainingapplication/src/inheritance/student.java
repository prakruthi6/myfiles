package inheritance;

public class student extends Person {
public int rollid;

/*public student(String name,int age, int rollid)
{
	super(name,age);
	this.rollid=rollid;
}*/
public void something()
{
	System.out.println("Studying");
}
}
