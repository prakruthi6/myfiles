package inheritance;

public class Employee extends Person {
public int empid;

/*public Employee(String name,int age, int empid) //Inheritance
{
	super(name,age);
	this.empid=empid;
}*/

public void something()
{
	System.out.println("Working");
}
}
