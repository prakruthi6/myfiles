package loops;

public class loopseg {

	public static void main(String[] args) {
    /*int x=0;
    while(x<10)
	{
	System.out.println("The value of x is "+x);
	x++;
	}
    
    int y=0;
    do {
    	System.out.println("The value of y iS "+y);
    	y=y+1;
	}while(y<10);
    
    for(int i=0;i<20;i++)
    {
    	System.out.println("The value of i "+i);
    }*/
	
		int a=0;
		int b=1;
		System.out.println(a);
		System.out.println(b);
		for(int i=0;i<=6;i++)
		{
			int sum=a+b;
			a=b;
			b=sum;
			System.out.println(sum);
			
		}
	}

}
