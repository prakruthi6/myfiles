package Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Testmain {
	static String Username;

	public static void main(String[] args) {

		try {
			String uname = "root";
			String pass = "1234";
			String url = "jdbc:mysql://localhost:3306/prakruthi?useSSL=false";
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, uname, pass);
			String query = "Select * from login";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			System.out.println("Welcome");
			System.out.println("Enter UN");
			Scanner scn = new Scanner(System.in);
			String Username = scn.next();
			
			while (rs.next()) {
				
				String name=rs.getString(1);
//				String pw=rs.getString(2);
				if((Username).equals(name))
				{
					System.out.println("User found");
					
					System.out.println("1.List the Record");
					System.out.println("2.Add a new record");
					System.out.println("3.Update an existing redord");
					System.out.println("4. Show my dob");
					System.out.println("5.Exit");
					
					System.out.println("Enter your choice");
					Scanner sc=new Scanner(System.in);
					int choice=sc.nextInt();
					
					switch(choice)
					{
					case 1:
						System.out.println("Listing the records");
						Listing();
						break;
					case 2:
						System.out.println("Adding a new record");
						Inserting();
						break;
					case 3:
						System.out.println("updating a new record");
						Updating();
						break;
					case 4:
						System.out.println("Dob");
						break;
					case 5:
						System.out.println("You are out of the system");
						break;
					}
				}
			} 

		} catch (Exception e) {
			System.out.println(e.getMessage());

		

	}

}
public static void Listing() {
	try {
		String uname="root";
		String pass="1234";
		String url="jdbc:mysql://localhost:3306/prakruthi?useSSl=false";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,uname,pass);
		String query ="Select * from person1";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);
		//st.executeUpdate();
		while(rs.next())
		{
	    int id= rs.getInt("id");
		String name= rs.getString("name");
		String email=rs.getString("email");
		
		long phone = rs.getLong("phone");
	
		System.out.println(id+ " "+name+ " "+email+ " "+phone);
		} 
	}
		catch(Exception e) {
		System.out.println(e.getMessage());
	}
}
 public static void Inserting()
{
try {
	String uname="root";
	String pass="1234";
	String url="jdbc:mysql://localhost:3306/prakruthi?useSSl=false";
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con=DriverManager.getConnection(url,uname,pass);
	
	String query="select max(id) from person1";
	Statement st = con.createStatement();
	ResultSet rs = st.executeQuery(query);
	rs.next();
	int localid=rs.getInt(1);
	

Scanner sc= new Scanner(System.in);
System.out.println("How many records to update?");
	int n=sc.nextInt();
	System.out.println("Enter name and phone");
	for(int i=0; i<n; i++)
	{
	
		localid++;
		
		String name=sc.next();
		int phone=sc.nextInt();
		String email=sc.next();
		String query1 ="insert into person1(id,name,email,phone) values ("+localid+", '"+name+"','"+email+"',"+phone+")";
		Statement st1 = con.createStatement();
		st1.executeUpdate(query1);
		System.out.println("Inserted");
	}
} catch(Exception e)
{
	System.out.println(e.getMessage());
}

}
 public static void Updating() {
	 try {
			String uname="root";
			String pass="1234";
			String url="jdbc:mysql://localhost:3306/prakruthi?useSSl=false";
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,uname,pass);
			
			
			String query ="update person1 where name="+Username+"";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			rs.next();
			System.out.println("Want to update new name and phone");
			/*System.out.println("Enter name to update");
			Scanner sc=new Scanner(System.in);
			String uname1=sc.next();
			if((Username).equals(uname))
			{
				
			}*/
            
			
	 } catch(Exception e)
	 {
		 System.out.println(e.getMessage());
	 }
		    
 }
}

