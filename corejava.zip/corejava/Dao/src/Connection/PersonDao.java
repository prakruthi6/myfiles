package Connection;

import java.util.List;

public interface PersonDao {
	//public void addperson();
 public List<person> getAllperson();
 
 
 /*public person getperson(int id);
 public void updateperson(person name);*/
 
}




