package Connection;

public class test {

	public static void main(String[] args) {
	PersonDao person= new persondaoimpl();
	//person.addperson();
	
	(person.getAllperson()).stream().forEach(p -> System.out.println("***"+p.id+"---"+p.name+"---"+p.email+"---"+p.phone+"--"));
	}

}
