package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Connectionfactory {
	    String connectionUrl="jdbc:mysql://localhost:3306/prakruthi?useSSL=false";
	    String dbUser="root";
	    String dbPwd="1234";
	    String driverClassName="com.mysql.cj.jdbc.Driver";
	    
	    private static Connectionfactory connectionfactory=null;
	    
	    private Connectionfactory() {
	    	try {
	    		Class.forName(driverClassName);
	    		
	    	} catch (ClassNotFoundException e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    
	public Connection getConnection() throws SQLException {
		Connection conn=null;
		conn=DriverManager.getConnection(connectionUrl, dbUser,dbPwd);
		return conn;
	}
	public static Connectionfactory getInstance() {
		if(connectionfactory==null) {
			connectionfactory=new Connectionfactory();
		}
		return connectionfactory;
	}
	
} 
