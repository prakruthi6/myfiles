package Connection;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
//import java.util.Scanner;

public class persondaoimpl implements PersonDao {
     Connection con=null;
     Statement st1=null;
     Statement st2=null;
     ResultSet resultSet=null;
      
     private Connection getConnection() throws SQLException {
    	 Connection conn;
    	 conn=Connectionfactory.getInstance().getConnection();
    	 return conn;
     }
/*public void addPerson() {
	try
	{
		con=getConnection();
		String query1="Select max(id) from person1";
		Statement st1=con.createStatement();
		ResultSet rs1=st1.executeQuery(query1);
		int localid=rs1.getInt(1);
		

		Scanner sc= new Scanner(System.in);
		System.out.println("How many records to update?");
			int n=sc.nextInt();
			System.out.println("Enter name and phone");
			for(int i=0; i<n; i++)
			{
			
				localid++;
				
				String name=sc.next();
				int phone=sc.nextInt();
				String email=sc.next();
				String query2 ="insert into person1(id,name,email,phone) values ("+localid+", '"+name+"','"+email+"',"+phone+")";
				Statement st2 = con.createStatement();
				st2.executeUpdate(query2);
				System.out.println("Inserted");
			}
		} catch(Exception e)
		{
			System.out.println(e.getMessage());
		} }
*/
		

 public List<person> getAllperson() {
	 List<person> listofPerson=new ArrayList<person>();
	 try {
		 con=getConnection();
		 String query="Select * from person1";
		 st1=con.createStatement();
		 ResultSet rs=st1.executeQuery(query);
		 while(rs.next())
		 {
			 int tempid=rs.getInt(1);
			 String tempname=rs.getString(2);
			 String tempemail=rs.getString(3);
			 int tempphone=rs.getInt(4);
			 listofPerson.add(new person(tempid, tempname, tempemail, tempphone));
		 }
	 } catch(Exception e) {}
	return listofPerson;
 }
    	 
    	 
     }

