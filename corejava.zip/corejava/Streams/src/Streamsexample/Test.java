package Streamsexample;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Student s1=new Student();
		Student s2=new Student();
		//Student s3=new Student();
		//Student s4=new Student();
		
		List<Student> sList=new ArrayList<>();
		sList.add(s1);
		sList.add(s2);
		//sList.add(s3);
		//sList.add(s4);
		 Scanner scn=new Scanner(System.in);
		 for(Student s:sList)
		 {
			 System.out.println("Enter name");
			 s.name=scn.next();
			 System.out.println("Enter age");
			 s.age=scn.nextInt();
			 System.out.println("Enter address");
			 s.address=scn.next();
		 }
		 for(Student s:sList)
		 {
			 System.out.println(s.name+" "+s.age+" "+s.address);
		 }
		 
	}

}
