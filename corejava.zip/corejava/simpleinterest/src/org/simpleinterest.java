package org;

public class simpleinterest {
 public int principle;
 public float rate;
 public int time;
 public float interest;
 
 public void calculatedinterest()
 {
	 interest=principle*rate*time/100;
	 System.out.println("The calculated interest is"+" "+interest);
	
 }
public void display()
{
	System.out.println("this program calculates simpleinterest");
	calculatedinterest();
}
}

