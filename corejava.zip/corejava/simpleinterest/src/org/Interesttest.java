package org;

public class Interesttest {

	public static void main(String[] args) {
		simpleinterest obj=new simpleinterest();
		obj.principle=1000;
		obj.rate=5;
		obj.time=3;
		obj.display();
	}

}
