package JDBCExample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class Insertdata {

	public static void main(String[] args) {
	    try {
			String uname="root";
			String pass="1234";
			String url="jdbc:mysql://localhost:3306/prakruthi?useSSl=false";
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,uname,pass);
			
			String query="select max(id) from person1";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			rs.next();
			int localid=rs.getInt(1);
			
		
		Scanner sc= new Scanner(System.in);
		System.out.println("How many records to update?");
			int n=sc.nextInt();
			System.out.println("Enter name and phone");
			for(int i=0; i<n; i++)
			{
			
				localid++;
				
				String name=sc.next();
				int phone=sc.nextInt();
				
				String query1 ="insert into person1(id,name,phone) values ("+localid+", '"+name+"',"+phone+")";
				Statement st1 = con.createStatement();
				st1.executeUpdate(query1);
				System.out.println("Inserted");
			}
	    } catch(Exception e)
	    {
	    	System.out.println(e.getMessage());
	    }

	}
}
