package org.model;

import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.entity.User;
import javax.sql.DataSource;


public class UsersModel {
public List<User> listUsers(DataSource dataSource)
{
	List<User> listUsers=new ArrayList<>();
	
	Connection connect=null;
	Statement stmt=null;
	ResultSet rs=null;
	
	
	try {
		connect=dataSource.getConnection();
		
		//step 2: Create a sql statement string
		String query="Select * from users";
		stmt= connect.createStatement();
		
		//step3 :Execute sql query
		rs=stmt.executeQuery(query);
		
		//step4: process the result set
		while(rs.next() ) {
			listUsers.add(new User(rs.getInt("users_id"),rs.getString("username"),rs.getString("email")));
		}
		} catch(SQLException e) {
			e.printStackTrace();
		}
	return listUsers;
}
}
