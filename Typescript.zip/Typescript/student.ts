class Student {
	fullName: string;
	constructor(public firstName: string, public middleInitial: string, public lastName: string) 
	{
	this.fullName= firstName + " " + middleInitial + " " + lastName;
}
}
interface Person {
firstName: string;
lastName: string;
}
function greater(person: Person) {
	return "Hello, " + person.firstName + " " +person.lastName;
}
let user= new Student("Prakruthi","C", "User");
console.log(greater(user));
