function greeter(person) {
	return "Hello, "+ person;
}
let user ='Prakruthi';
console.log(greeter(user));