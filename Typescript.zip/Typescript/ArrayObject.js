var j;
var arr = new Array("Prakruthi", "621998", "Prakru", "pc");
for (var i = 0; i < arr.length; i++) {
    console.log(arr[i]);
}
console.log("Above program is same as below one");
for (j in arr) {
    console.log(arr[j]);
}
