function greeter(person) {
    return "Hello, " + person;
}
var user = 'Prakruthi';
console.log(greeter(user));
